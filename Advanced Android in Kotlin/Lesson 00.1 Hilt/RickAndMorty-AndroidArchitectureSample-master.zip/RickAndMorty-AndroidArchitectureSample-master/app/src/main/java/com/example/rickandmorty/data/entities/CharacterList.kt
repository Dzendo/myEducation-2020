package com.example.rickandmorty.data.entities

data class CharacterList(
    val info: Info,
    val results: List<Character>
)