package com.mechanitis.demo.junit5;

public class Fixture {
    public static int apiVersion() {
        return 13;
    }
}
