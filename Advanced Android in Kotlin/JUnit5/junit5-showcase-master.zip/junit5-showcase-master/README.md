# JUnit 5 Basics

This is the code used in the "Writing Tests With JUnit 5" IntelliJ IDEA video: https://youtu.be/we3zJE3hlWE
