# junit5-jupiter-starter-ant

The `junit5-jupiter-starter-ant` project demonstrates how to execute JUnit Jupiter
tests using [Apache Ant](https://ant.apache.org/) 1.10.4 or higher.

This sample project does not aim to demonstrate how to use the JUnit Jupiter APIs.

For detailed  information on the JUnit Jupiter programming and extension models,
please consult the [User Guide](http://junit.org/junit5/docs/current/user-guide/).
