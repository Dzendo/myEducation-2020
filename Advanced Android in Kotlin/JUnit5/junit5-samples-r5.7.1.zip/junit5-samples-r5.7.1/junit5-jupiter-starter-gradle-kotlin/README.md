# junit5-jupiter-starter-gradle-kotlin

The `junit5-jupiter-starter-gradle-kotlin` project demonstrates how to run tests based on
JUnit Jupiter using [Gradle's native JUnit Platform support], Gradle's Kotlin DSL
and code and tests written in Kotlin.

[Gradle's native JUnit Platform support]: https://docs.gradle.org/current/userguide/java_testing.html#using_junit5
