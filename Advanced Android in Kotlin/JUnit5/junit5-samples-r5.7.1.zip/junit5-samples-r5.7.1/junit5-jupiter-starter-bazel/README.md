# junit5-jupiter-starter-bazel

The `junit5-jupiter-starter-bazel` project demonstrates how to execute JUnit Jupiter
tests using Bazel.

Run `./bazelisk.py test //...` to execute all tests.
