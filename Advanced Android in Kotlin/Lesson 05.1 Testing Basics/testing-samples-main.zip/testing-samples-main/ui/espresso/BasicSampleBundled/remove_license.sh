zip -d libs/hamcrest-core-1.3.jar LICENSE.txt
zip -d libs/hamcrest-library-1.3.jar LICENSE.txt
zip -d libs/hamcrest-integration-1.3.jar LICENSE.txt

