Android Data Binding Codelab
=============================================
Follow the codelab in

https://github.com/googlecodelabs/android-databinding


License
--------

Copyright 2018 Google LLC. Licensed under the Apache License, Version 2.0.
